import math
import random

board = [' ' for _ in range(9)]
human_player = 'X'
ai_player = 'O'


def print_board():
    row1 = '|'.join([board[i] for i in range(3)])
    row2 = '|'.join([board[i] for i in range(3, 6)])
    row3 = '|'.join([board[i] for i in range(6, 9)])

    print(row1)
    print('-' * 5)
    print(row2)
    print('-' * 5)
    print(row3)


def get_available_moves():
    return [i for i, x in enumerate(board) if x == ' ']


def check_win(player):
    # Check rows
    for i in range(0, 9, 3):
        if (board[i] == board[i + 1] == board[i + 2] == player):
            return True

    # Check columns
    for i in range(3):
        if (board[i] == board[i + 3] == board[i + 6] == player):
            return True

    # Check diagonals
    if (board[0] == board[4] == board[8] == player):
        return True
    if (board[2] == board[4] == board[6] == player):
        return True

    return False


def check_draw():
    return ' ' not in board


def evaluate():
    if check_win(ai_player):
        return 1
    elif check_win(human_player):
        return -1
    else:
        return 0


def minimax(depth, is_maximizing):
    if check_win(ai_player):
        return 1
    elif check_win(human_player):
        return -1
    elif check_draw():
        return 0

    if is_maximizing:
        best_score = -math.inf
        for move in get_available_moves():
            board[move] = ai_player
            score = minimax(depth + 1, False)
            board[move] = ' '
            best_score = max(best_score, score)
        return best_score
    else:
        best_score = math.inf
        for move in get_available_moves():
            board[move] = human_player
            score = minimax(depth + 1, True)
            board[move] = ' '
            best_score = min(best_score, score)
        return best_score


def ai_turn():
    best_score = -math.inf
    best_move = None
    for move in get_available_moves():
        board[move] = ai_player
        score = minimax(0, False)
        board[move] = ' '
        if score > best_score:
            best_score = score
            best_move = move
    board[best_move] = ai_player


def human_turn():
    valid_move = False
    while not valid_move:
        move = input("Enter move (0-8): ")
        try:
            move = int(move)
            if move in get_available_moves():
                board[move] = human_player
                valid_move = True
            else:
                print("Invalid move. Try again.")
        except ValueError:
            print("Invalid input. Try again.")


def play_game():
    print("Welcome to Tic-Tac-Toe!")
    print_board()
   
    if random.choice([True, False]):
        print("You go first.")
        while not check_win(human_player) and not check_win(ai_player) and not check_draw():
            human_turn()
            print_board()
            if check_win(human_player):
                print("Congratulations! You won!")
                return
            elif check_draw():
                print("It's a draw!")
                return
            ai_turn()
            print_board()
            if check_win(ai_player):
                print("Sorry, you lost.")
                return
    else:
        print("I'll go first.")
        while not check_win(human_player) and not check_win(ai_player) and not check_draw():
            ai_turn()
            print_board()
            if check_win(ai_player):
                print("Sorry, you lost.")
                return
            elif check_draw():
                print("It's a draw!")
                return
            human_turn()
            print_board()
            if check_win(human_player):
                print("Congratulations! You won!")
                return

play_game()